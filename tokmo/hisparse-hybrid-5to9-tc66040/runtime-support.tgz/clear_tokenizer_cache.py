#!/usr/bin/env python3
"""Clear only CPU tokenizer caches after requests drain; save every API's ack."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import time
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True, help="Direct model API URL")
    parser.add_argument("--expected-apis", type=int, default=1)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def scrape():
        with opener.open(args.url.rstrip("/") + "/metrics", timeout=5) as response:
            return response.read().decode()

    def values(text, name):
        return [float(value) for value in re.findall(
            r"^" + re.escape(name) + r"(?:\{[^\n]*\})?\s+([\d.eE+-]+)$", text, re.M)]

    def api_values(text, name):
        result = {}
        for labels, value in re.findall(
                r"^" + re.escape(name) + r"\{([^\n]*)\}\s+([\d.eE+-]+)$", text, re.M):
            rank = re.search(r'(?:^|,)api_process="([^"]+)"', labels)
            if rank:
                result[rank[1]] = float(value)
        return result

    before = scrape()
    for metric in ("vllm:num_requests_running", "vllm:num_requests_waiting"):
        current = values(before, metric)
        if not current or any(current):
            raise RuntimeError(f"Requests are not confirmed drained: {metric}={current}")
    ranks = {str(i) for i in range(args.expected_apis)}
    if set(api_values(before, "vllm:tokenizer_cache_bytes")) != ranks:
        raise RuntimeError("Not every API exposes the tokenizer cache")
    epoch = uuid.uuid4().hex
    epoch_file = ROOT / "runtime/tokenizer-cache.epoch"
    temporary = epoch_file.with_suffix("." + epoch)
    temporary.write_text(epoch + "\n")
    temporary.replace(epoch_file)
    expected = int(hashlib.sha256(epoch.encode()).hexdigest()[:12], 16)
    deadline = time.monotonic() + 15
    while True:
        after = scrape()
        actual = api_values(after, "vllm:tokenizer_cache_epoch")
        size = api_values(after, "vllm:tokenizer_cache_bytes")
        passed = (set(actual) == set(size) == ranks
                  and all(value == expected for value in actual.values())
                  and not any(size.values()))
        if passed or time.monotonic() >= deadline:
            break
        time.sleep(0.25)
    result = {"recorded_at": datetime.datetime.now().astimezone().isoformat(),
              "scope": "CPU tokenizer caches only", "url": args.url,
              "epoch": epoch, "expected_epoch_metric": expected,
              "active_epochs": actual, "bytes": size, "passed": passed}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as out:
        json.dump(result, out, indent=2)
        out.write("\n")
    print(json.dumps(result))
    if not passed:
        raise RuntimeError("Tokenizer cache reset did not receive every API acknowledgement")


if __name__ == "__main__":
    main()
