"""Explicit read-only RPCs; cache auditing synchronizes GPU work on request."""
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import time


class CapacityObserver:
    def pd_capacity_snapshot(self):
        from vllm.distributed import get_dcp_group, get_tensor_model_parallel_rank
        from vllm.v1.core.kv_cache_utils import get_kv_cache_capacity

        role = os.environ["KIMI31_PD_ROLE"]
        if role not in ("prefill", "decode"):
            raise ValueError("Unknown PD role")
        runner = self.model_runner
        cache = runner.kv_cache_config
        config = self.vllm_config
        parallel = config.parallel_config
        tokens, concurrency = get_kv_cache_capacity(config, cache)
        storages = {}
        for tensor in runner.kv_caches:
            storage = tensor.untyped_storage()
            storages[(str(tensor.device), int(storage.data_ptr()))] = storage.nbytes()

        # Copy config objects before varying the reference length. Live state is untouched.
        budgets = []
        for length in (134096, 207413, 295517, config.model_config.max_model_len):
            reference = copy.copy(config)
            reference.model_config = copy.copy(config.model_config)
            reference.model_config.max_model_len = length
            per_group = [
                math.ceil(g.kv_cache_spec.max_memory_usage_bytes(reference) /
                          g.kv_cache_spec.page_size_bytes)
                for g in cache.kv_cache_groups if not g.host_resident
            ]
            total = sum(per_group)
            budgets.append({"input_plus_output_tokens": length,
                            "device_blocks_per_request_by_group": per_group,
                            "device_blocks_per_request": total,
                            "max_requests_without_shared_prefix_or_reserve":
                                (cache.num_blocks - 1) // total,
                            "note": "Spec peak budget; excludes extra in-flight transfer references and operating reserve"})
        groups = []
        for index, group in enumerate(cache.kv_cache_groups):
            spec = group.kv_cache_spec
            per_layer = getattr(spec, "kv_cache_specs", {})
            representative = next(iter(per_layer.values())) if per_layer else spec
            groups.append({"group": index, "layers": len(group.layer_names),
                           "spec": type(representative).__name__,
                           "block_size": spec.block_size,
                           "page_size_bytes": spec.page_size_bytes,
                           "dcp_sharded": getattr(representative, "dcp_sharded", None),
                           "mamba_cache_mode": getattr(representative, "mamba_cache_mode", None),
                           "num_speculative_blocks": getattr(representative, "num_speculative_blocks", None),
                           "num_prefill_checkpoint_blocks": getattr(representative, "num_prefill_checkpoint_blocks", None),
                           "host_resident": group.host_resident})
        result = {"wall_ns": time.time_ns(), "role": role,
                  "tp_rank": get_tensor_model_parallel_rank(),
                  "dcp_rank": get_dcp_group().rank_in_group,
                  "tp": parallel.tensor_parallel_size,
                  "dp": parallel.data_parallel_size,
                  "dcp": parallel.decode_context_parallel_size,
                  "ep": parallel.tensor_parallel_size * parallel.data_parallel_size,
                  "pool_blocks": cache.num_blocks,
                  "usable_pool_blocks": cache.num_blocks - 1,
                  "native_reference_token_equivalent": tokens,
                  "native_max_concurrency_at_reference_length": concurrency,
                  "reference_length": config.model_config.max_model_len,
                  "deduplicated_kv_storage_bytes": sum(storages.values()),
                  "groups": groups, "request_block_budgets": budgets,
                  "cache_mutated": False,
                  "observer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        budget_names = ("requested_memory", "total_consumed", "peak_activation_memory",
                        "cudagraph_memory_estimate", "available_kv_cache_memory_bytes")
        budget = {}
        for name in budget_names:
            value = getattr(self, name, None)
            if isinstance(value, (int, float)):
                budget[name] = value
        weight_bytes = getattr(runner, "model_memory_usage", None)
        if isinstance(weight_bytes, (int, float)):
            budget["model_runner_model_memory_usage"] = weight_bytes
        result["memory_budget_bytes"] = budget
        result["worker_class"] = type(self).__name__
        folder = Path("/work/deployment-evidence/kv-capacity") / role
        folder.mkdir(parents=True, exist_ok=True)
        (folder / f"tp-{result['tp_rank']:02d}.json").write_text(json.dumps(result, indent=2) + "\n")
        return result


    def pd_connector_geometry(self):
        from vllm.distributed.kv_transfer import get_kv_transfer_group
        group = get_kv_transfer_group()
        connectors = getattr(group, "_connectors", [group])
        result = []
        for connector in connectors:
            worker = getattr(connector, "connector_worker", None)
            names = getattr(worker, "registered_layer_names", [])
            regions = []
            for index, name in enumerate(names):
                spec = worker._layer_specs[name]
                regions.append({"layer": name, "kind": type(spec).__name__,
                                "block_size": spec.block_size,
                                "dcp_sharded": spec.dcp_sharded,
                                "row_bytes": getattr(spec, "state_content_size_bytes", None),
                                "registered_stride": worker.block_len_per_layer[index],
                                "registered_payload": worker.kv_block_len_per_layer[index]})
            result.append({"connector": type(connector).__name__, "regions": regions})
        return result


    def pd_hisparse_cache_audit(self):
        """Run the fixed local read-only probe; report diagnostics without raising."""
        import runpy
        try:
            return runpy.run_path("/work/pd_cache_probe.py")["audit"](self)
        except Exception as error:
            return {"rank": self.rank, "status": "probe_error", "error": repr(error),
                    "checked_rows": 0, "no_cache_mutation": True}

    def pd_store_runtime_config(self):
        from vllm.distributed.kv_transfer import get_kv_transfer_group
        group = get_kv_transfer_group()
        result = []
        for connector in getattr(group, "_connectors", [group]):
            worker = getattr(connector, "connector_worker", None)
            if worker is not None and hasattr(worker, "disk_offload_buffer_budget_bytes"):
                result.append({"connector": type(connector).__name__,
                               "disk_offload_buffer_budget_bytes": worker.disk_offload_buffer_budget_bytes})
        return result
